var radiotunes = require('yl.radiotunes');
radiotunes.addEventListener('begin_interruption', function(e) {
  if(myapp.radio === null) {
    return;
  }

  myapp.radio.pause();
});

radiotunes.addEventListener('end_interruption', function(e) {
  if(myapp.radio === null) {
    return;
  }

  if(myapp.radio.isPaused()) {
    myapp.radio.play();
  }
});

radiotunes.addEventListener('headphone_unplugged', function(e) {
  if(myapp.radio === null) {
    return;
  }

  if(myapp.radio.isPlaying()) {
    myapp.radio.pause();
  }
});

radiotunes.addEventListener('remote_control_toggle_play_pause', function(e) {
  if(myapp.radio === null) {
    return;
  }

  if(myapp.radio.isPaused()) {
    myapp.radio.play();
  } else {
    myapp.radio.pause();
  }
});

radiotunes.addEventListener('remote_control_pause', function(e) {
    if(myapp.radio === null) {
        return;
    }

    if(myapp.radio.isPlaying()) {
        myapp.radio.pause();
    }
});

radiotunes.addEventListener('remote_control_play', function(e) {
    if(myapp.radio === null) {
        return;
    }

    if(myapp.radio.isPaused()) {
        myapp.radio.play();
    }
});

radiotunes.addEventListener('remote_control_next_track', function(e) {
  // Add code to play next radio station here.
});

radiotunes.addEventListener('remote_control_previous_track', function(e) {
  // Add code to play previous radio station here.
});

var myapp = {};
myapp.ui = {};
myapp.ui.main = {};
myapp.ui.rec = {};
myapp.radio = null;
myapp.recordingCounter = 0;
myapp.recordings = [];

myapp.bindEvents = function(radio) {
  Ti.API.info("radio object created " + myapp.radio);
  myapp.radio.addEventListener('metadata', function(e) {
    if(e.name !== undefined) {
      Ti.API.info("Radio name: " + e.name);
    }
    if(e.genre !== undefined) {
      Ti.API.info("Radio genre: " + e.genre);
    }
    if(e.url !== undefined) {
      Ti.API.info("Radio url: " + e.url);
    }
  });

  myapp.radio.addEventListener('title', function(e) {
    myapp.ui.main.titleLabel.setText("Now playing: " + e.title);
  });

  myapp.radio.addEventListener('state', function(e) {
    var state = e.state;
    if(state == 0) { // Stopped
      myapp.ui.main.statusLabel.setText("Status: Stopped");
      myapp.ui.main.playButton.setImage("play.png");
      myapp.ui.main.playButton.setEnabled(true);
      myapp.ui.main.recButton.setEnabled(false);
    } else if(state == 1) { // Connecting
      myapp.ui.main.statusLabel.setText("Status: Connecting");
      myapp.ui.main.titleLabel.setText("");
      myapp.ui.main.playButton.setImage("pause.png");
      myapp.ui.main.playButton.setEnabled(false);
      myapp.ui.main.recButton.setEnabled(false);
    } else if(state == 2) { // Buffering
      myapp.ui.main.statusLabel.setText("Status: Buffering");
      myapp.ui.main.playButton.setImage("pause.png");
      myapp.ui.main.playButton.setEnabled(true);
      myapp.ui.main.recButton.setEnabled(false);
    } else if(state == 3) { // Playing
      myapp.ui.main.statusLabel.setText("Status: Playing");
      myapp.ui.main.playButton.setImage("pause.png");
      myapp.ui.main.playButton.setEnabled(true);
      myapp.ui.main.recButton.setEnabled(true);
    } else if(state == 4) { // Error
      var error = e.error;
      // Special handling for ASX playlist which is parsed by YLHTTPRadio. We need to switch over to 
      // YLMMSRadio if the parsed URL is a valid mms URL.
      if(error == 2) {
        var url = myapp.radio.url();
        myapp.radio.shutdown();
        myapp.radio = null;
        myapp.radio = radiotunes.createMMSRadio(url);
        myapp.bindEvents(myapp.radio);
        myapp.radio.play();

        return;
      }

      myapp.ui.main.statusLabel.setText("Status: Error");
      myapp.ui.main.playButton.setImage("play.png");
      myapp.ui.main.playButton.setEnabled(true);
      myapp.ui.main.recButton.setEnabled(false);
      if(error == 1) { // Playlist parsing error
        myapp.ui.main.titleLabel.setText("Playlist could not be parsed.");
      } else if(error == 3) { // Stream get property error
        myapp.ui.main.titleLabel.setText("File stream get property failed.");
      } else if(error == 4) { // Stream open error
        myapp.ui.main.titleLabel.setText("File stream could not be opened.");
      } else if(error == 5) { // AudioQueue create error
        myapp.ui.main.titleLabel.setText("Audio queue could not be created.");
      } else if(error == 6) { // AudioQueue buffer create error
        myapp.ui.main.titleLabel.setText("Audio buffers could not be created.");
      } else if(error == 7) { // AudioQueue enqueue error
        myapp.ui.main.titleLabel.setText("Audio queue enqueue failed.");
      } else if(error == 8) { // AudioQueue start error
        myapp.ui.main.titleLabel.setText("Audio queue could not be started.");
      } else if(error == 9) { // Decoding error
        myapp.ui.main.titleLabel.setText("Audio decoding error.");
      } else if(error == 10) { // Host not reachable
        myapp.ui.main.titleLabel.setText("Radio host not reachable.");
      } else if(error == 11) { // Network error
        myapp.ui.main.titleLabel.setText("Network connection error.");
      }
    }
  });
  
  myapp.radio.addEventListener('recording_started', function(e) {
    Ti.API.info("Recording started to path: " + e.path);
  });
  
  myapp.radio.addEventListener('recording_stopped', function(e) {
    Ti.API.info("Recording stopped");
    myapp.ui.main.recButton.setImage('record_off.png');
    
    var filename = e.path.substring(e.path.lastIndexOf('/') + 1);
    myapp.recordings.push({title: filename});
  });
  
  myapp.radio.addEventListener('recording_failed', function(e) {
    var code = e.code;
    if(code == 0) {
      Ti.API.info("Recording failed: initialisation error");
    } else if(error == 1) {
      Ti.API.info("Recording failed: file error");
    } else if(error == 2) {
      Ti.API.info("Recording failed: format error");
    } else if(error == 3) {
      Ti.API.info("Recording failed: write error");
    }
    myapp.ui.main.recButton.setImage('record_off.png');
  });
};

myapp.ui.createWindow = function() {
  var rec = Ti.UI.createWindow({backgroundColor: 'black', title: 'Recordings', navBarHidden: false});
  
  myapp.ui.rec.table = Ti.UI.createTableView({data: myapp.recordings, top: 0, width: 320, height: 345});
  myapp.ui.rec.table.addEventListener('click', function(e) {
    if(myapp.audioPlayer) {
      myapp.audioPlayer.stop();
      myapp.audioPlayer = null;
    }

    myapp.ui.rec.statusLabel.setText("");
    var filename = myapp.recordings[e.index].title;
    myapp.ui.rec.titleLabel.setText(filename);

    var f = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, filename);
    myapp.audioPlayer = Ti.Media.createSound({url: f.nativePath});
    if(myapp.audioPlayer) {
      myapp.audioPlayer.setVolume(0.5);
      myapp.audioPlayer.addEventListener('complete', function(e) {
        myapp.ui.rec.playButton.setImage('play.png');
      });

      myapp.audioPlayer.addEventListener('error', function(e) {
        myapp.ui.rec.statusLabel.setText('Player error');
        myapp.ui.rec.playButton.setImage('play.png');
      });

      var duration = myapp.audioPlayer.getDuration();
      var durationString = "" + parseInt(duration / 60) + ":" + parseInt(duration % 60);
      myapp.ui.rec.statusLabel.setText(durationString);

      myapp.audioPlayer.play();
      myapp.ui.rec.playButton.setImage('pause.png');
    } else {
      myapp.ui.rec.statusLabel.setText("Player could not be created.");
    }

    var section = myapp.ui.rec.table.data[0];
    var rowCount = section.rowCount;
    for(var x = 0; x < rowCount; x++) {
      var row = section.rows[x];
      if(x == e.index) {
        row.setRightImage("now_playing.png");
      } else {
        row.setRightImage(null);
      }
    }
  });
  rec.add(myapp.ui.rec.table);
  
  myapp.ui.rec.statusLabel = Ti.UI.createLabel({top: 381, left: 68, width: 243, height: 21, text: "", color: 'white', font: {fontSize: 14, fontName: 'Helvetica'}});
  myapp.ui.rec.statusLabel.setMinimumFontSize(10);
  rec.add(myapp.ui.rec.statusLabel);

  myapp.ui.rec.titleLabel = Ti.UI.createLabel({top: 360, left: 68, width: 243, height: 21, text: "", color: 'white', font: {fontSize: 14, fontName: 'Helvetica', fontWeight: 'bold'}});
  rec.add(myapp.ui.rec.titleLabel);

  myapp.ui.rec.playButton = Ti.UI.createButton({top: 356, left: 5, width: 55, height: 55, image: "play.png", style: Ti.UI.iPhone.SystemButtonStyle.PLAIN});
  myapp.ui.rec.playButton.addEventListener('click', function(e) {
    if(myapp.audioPlayer === null) {
      return;
    }
    
    if(myapp.audioPlayer.isPlaying()) {
      myapp.audioPlayer.pause();
      myapp.ui.rec.playButton.setImage('play.png');
    } else {
      myapp.audioPlayer.play();
      myapp.ui.rec.playButton.setImage('pause.png');
    }
  });
  rec.add(myapp.ui.rec.playButton);
  
  var navButton = Ti.UI.createButton({title: 'Recordings', style: Ti.UI.iPhone.SystemButtonStyle.DONE});
  navButton.addEventListener('click', function(e) {
    if(myapp.radio && myapp.radio.isPlaying()) {
      myapp.radio.pause();
    }
    
    myapp.ui.rec.table.setData(myapp.recordings);
    nav.open(rec, {animated: true});
  });
  
  var win = Ti.UI.createWindow({backgroundColor: 'black', navBarHidden: false, title: "RadioTunes", rightNavButton: navButton});

  var data = [
    {title: "TRT Radyo 1"},
    {title: "BBC Radio 1"},
    {title: "Boost.FM"},
    {title: "Soundtracks"},
    {title: "Radio Javan"},
    {title: "Power FM"},
    {title: "181.FM Chilled"}];
  myapp.ui.main.table = Ti.UI.createTableView({data: data, top: 0, width: 320, height: 310});
  myapp.ui.main.table.addEventListener('click', function(e) {
    if(myapp.radio) {
      myapp.radio.shutdown();
      myapp.radio = null;
    }

    myapp.ui.main.statusLabel.setText("");
    myapp.ui.main.titleLabel.setText("");

    var url = myapp.radioStations[e.index];
    if(url.slice(0, 3) == "mms") {
      myapp.radio = radiotunes.createMMSRadio(url);
    } else {
      myapp.radio = radiotunes.createHTTPRadio(url);
    }

    if(myapp.radio) {
      myapp.bindEvents(myapp.radio);
      myapp.radio.play();
    } else {
      Ti.API.info("radio object is NULL");
    }

    var section = myapp.ui.main.table.data[0];
    var rowCount = section.rowCount;
    for(var x = 0; x < rowCount; x++) {
      var row = section.rows[x];
      if(x == e.index) {
        row.setRightImage("now_playing.png");
      } else {
        row.setRightImage(null);
      }
    }
  });
  win.add(myapp.ui.main.table);

  var volumeIcon = Ti.UI.createImageView({image: 'volume.png', top: 368, left: 131, width: 42, height: 32});
  win.add(volumeIcon);

  myapp.ui.main.volumeSlider = Ti.UI.createSlider({top: 373, left: 179, width: 135, height: 23, min: 0, max: 1, value: 0.5});
  myapp.ui.main.volumeSlider.addEventListener('change', function(e) {
    if(myapp.radio) {
      myapp.radio.setVolume(e.value);
    }
  });
  myapp.ui.main.volumeSlider.setThumbImage('knob.png');
  myapp.ui.main.volumeSlider.setLeftTrackImage('scrub_left.png');
  myapp.ui.main.volumeSlider.setRightTrackImage('scrub_right.png');
  win.add(myapp.ui.main.volumeSlider);

  myapp.ui.main.statusLabel = Ti.UI.createLabel({top: 311, left: 8, width: 304, height: 21, text: "", color: 'white', font: {fontSize: 14, fontName: 'Helvetica', fontWeight: 'bold'}});
  win.add(myapp.ui.main.statusLabel);

  myapp.ui.main.titleLabel = Ti.UI.createLabel({top: 331, left: 8, width: 304, height: 21, text: "", color: 'white', font: {fontSize: 14, fontName: 'Helvetica'}});
  myapp.ui.main.titleLabel.setMinimumFontSize(10);
  win.add(myapp.ui.main.titleLabel);

  myapp.ui.main.playButton = Ti.UI.createButton({top: 356, left: 5, width: 55, height: 55, image: "play.png", style: Ti.UI.iPhone.SystemButtonStyle.PLAIN});
  myapp.ui.main.playButton.addEventListener('click', function(e) {
    if(myapp.radio === null) {
      Ti.API.info("radio object is NULL");
      return;
    }

    var playing = myapp.radio.isPlaying();
    if(myapp.radio.isPlaying()) {
      Ti.API.info("pausing radio");
      myapp.radio.pause();
    } else {
      Ti.API.info("playing radio");
      myapp.radio.play();
    }
  });
  win.add(myapp.ui.main.playButton);

  myapp.ui.main.recButton = Ti.UI.createButton({top: 356, left: 60, width: 55, height: 55, image: "record_off.png", style: Ti.UI.iPhone.SystemButtonStyle.PLAIN});
  myapp.ui.main.recButton.addEventListener('click', function(e) {
    if(myapp.radio === null) {
      Ti.API.info("radio object is NULL");
      return;
    }

    if(!myapp.radio.isPlaying()) {
      return;
    }

    if(myapp.radio.isRecording()) {
      myapp.ui.main.recButton.setImage('record_off.png');
      myapp.radio.stopRecording();
    } else {
      var filename = "recording" + myapp.recordingCounter++ + "." + myapp.radio.fileExtensionHint();
      var f = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, filename);
      myapp.ui.main.recButton.setImage('record_on.png');
      myapp.radio.startRecordingWithDestination(f.nativePath);
    }
  });
  win.add(myapp.ui.main.recButton);
  myapp.ui.main.recButton.setEnabled(false);

  var nav = Titanium.UI.iPhone.createNavigationGroup({window: win});
  var container = Ti.UI.createWindow();
  container.add(nav);

  return container;
};

// radio stations
myapp.radioStations = ["mmsh://95.0.159.133/RADYO1",
  "http://www.bbc.co.uk/radio/listen/live/r1.asx",
  "http://108.168.244.242:8000/stream/1/",
  "http://yp.shoutcast.com/sbin/tunein-station.pls?id=5266",
  "http://stream.radiojavan.com/radiojavan",
  "http://46.20.4.43:8130/listen.pls",
  "http://www.181.fm/winamp.pls?station=181-chilled&style=mp3&description=Chilled%20Out&file=181-chilled.pls"];

myapp.window = myapp.ui.createWindow();
myapp.window.open();

